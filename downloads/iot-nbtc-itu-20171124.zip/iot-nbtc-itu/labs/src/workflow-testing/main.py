import time

for i in range(10):
    print('This is my message number: ', str(i))
    time.sleep(1)
    
