ssid = 'my-wifi'
password = 'my-wifi-password'
