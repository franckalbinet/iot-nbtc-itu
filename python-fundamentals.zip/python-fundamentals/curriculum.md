> [Internet of Things (IoT) | Training Course](curriculum.md) ▸ **Python fundamentals**

# Python fundamentals

1. [Language pieces](2-python-language-pieces.ipynb)
2. [Data types](3-data-types.ipynb)
3. [Statements](4-statements.ipynb)
4. [Abstraction with functions](5-abstraction-with-functions.ipynb)
5. [Modules and namespaces](6-modules-and-namespaces.ipynb)
6. [More abstraction with Classes](7-more-abstraction-with-classes.ipynb)


